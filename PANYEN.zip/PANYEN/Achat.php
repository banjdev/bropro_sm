<!DOCTYPE HTML>
<html>
<head><title>ACHAT</title>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="css/bootstrap.min.css">
 <link href="css/mdb.min.css" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNav">
	    <ul class="navbar-nav">
	      <li class="nav-item active">
	        <a class="nav-link" href="index.html">Aceuil<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="Achat.php">Achat</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="connexion.php">Vente</a>
	      </li>

	    </ul>
	  </div>
    <div class="navbar-header">
      <a id="intro_logo"class="navbar-brand" href="index.html"><img src="img/logo.png" width="50%"></a>
     </div>
	</nav>
  <div class="parallaxpub">
    <div>
    <p>OU pa travay ou vle gen lajan nan poch ou ?<br></p>
    <h3><a href="connexion.php"  class="btn btn-warning">KLIK PAM</a></h3>

  </div>
  </div>
  <div class="container-fluid">
       <div class="row">
<?php

include('fonction.php');
session_start();
if (!isset($_SESSION['ank'])) {
  $CodeAChat=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz@#$%^&*()-_![]{}?/\|'),0,30);
  $_SESSION['ank']=$CodeAChat;
}else{
  $CodeAChat=$_SESSION['ank'];
}
    echo "<form method='post' action=''>";
          $Categorie=$conn->query("SELECT distinct Categorie FROM produit ORDER BY Categorie ASC ");
          echo "<SELECT name='choix'>";
          echo "<option VALUE='all'>All</VALUE>";
          while ($Cata=$Categorie->fetch()) {
            echo"<option VALUE='".$Cata['Categorie']."'>".$Cata['Categorie']."</option><br>";
          }
          echo "</SELECT>";
          echo "<input type='submit' name='Categorie' id='bouton' value='Selectionner'>";
        echo "</form>";
if (isset($_GET['ag'])) {//si se yon lyen i voyew la
   $CodeS=$_GET['ag'];
   $CodeShare=$_GET['sh'];
   $CodeProduitReturn=$_GET['prod'];
   $CodeAgent=$_GET['ag'];

   $personneCode=$conn->query("SELECT * FROM share  WHERE CodeShare='$CodeShare' and CodeProdutShare='$CodeProduitReturn' ");//retourne yon sel pwodwi
   while ($share=$personneCode->fetch()) {
     $CodeAgent1=$share['CodeAgent'];
     $CodeProdutShare=$share['CodeProdutShare'];
     echo "antre1";
   }
   echo "antre2";
   if (!isset($CodeAgent1)) {
     echo "antre3";
     $Entre="INSERT INTO share (CodeShare,CodeAgent,CodeProdutShare)
     VALUES('$CodeShare','$CodeS','$CodeProduitReturn')";
     $conn->exec($Entre);
   }

?>



<?php
   //$ReherchePersonne=$conn->query("SELECT * FROM share WHERE Code='$CodeAgent' ");//pour afiche tot produit clien sa
      if (isset($_POST['Categorie'])) {
        if ($_POST['choix']=='all') {
         $VoirProduit=$conn->query("SELECT s.CodeProdutShare, p.CodeProduit,p.CodeProduit,p.PrixUnitaire,p.QuantiteProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeAgent' and s.CodeProdutShare=p.CodeProduit ");
         while ($ProduitCode=$VoirProduit->fetch()) {
           $CodeProduit=$ProduitCode['p.CodeProduit'];
           $PrixProduit=$ProduitCode['p.PrixUnitaire'];
           $QuantiteProduit=$ProduitCode['p.QuantiteProduit'];
             $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
           while ($Diminuer=$QuantiteVendue->fetch()) {
             $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

           }
           $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
           while ($share=$TextProduitShare->fetch()) {
             $ExiteCode=$share['Agent'];
           }

           if (($QuantiteProduit-$QuantiteV)>0) {
             # code..
             echo'<div class="col-md-3"';
        echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
         .'<form method="post" action="">';
         ?>

         <select name="choix">"

         <option value="Haiti">HAITI</option>
         <option value="USA">USA</option>
         <option value="BRESIL">BRESIL</option>
         <option value="CHILIE">CHILIE</option>
         <option value="ARGENTINE">ARGENTINE</option>
         </select>
         <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
         <?php
         $Val=($QuantiteProduit-$QuantiteV);
         echo '

         <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
         <input type="Tel" name="tel" placeholder="Numero telephone">
         <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
         <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
         <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
         <input type="submit" name="Achat" value="ACHATER" id="bouton">
         </form>';
         echo'</div>';

           }

     }
}
     else{
         $Categoriechoix=$_POST['choix'];

         $VoirProduit=$conn->query("SELECT s.CodeProdutShare, p.CodeProduit,p.CodeProduit,p.PrixUnitaire,p.QuantiteProduit,p.Categorie FROM share s, produit p WHERE s.CodeProdutShare='$CodeAgent' and s.CodeProdutShare=p.CodeProduit and p.Categorie='$Categoriechoix' ");
         while ($ProduitCode=$VoirProduit->fetch()) {
           $CodeProduit=$ProduitCode['p.CodeProduit'];
           $PrixProduit=$ProduitCode['p.PrixUnitaire'];
           $QuantiteProduit=$ProduitCode['p.QuantiteProduit'];
             $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
           while ($Diminuer=$QuantiteVendue->fetch()) {
             //$CodeProduitVendu=$Diminuer['CodeProduit'];
             $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

           }
           $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
           while ($share=$TextProduitShare->fetch()) {
             $ExiteCode=$share['Agent'];
           }
           if (($QuantiteProduit-$QuantiteV)>0) {
             # code...
             echo'<div class="col-md-3"';
        echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
         .'<form method="post" action="">';
         ?>

         <select name="choix">"

         <option value="Haiti">HAITI</option>
         <option value="USA">USA</option>
         <option value="BRESIL">BRESIL</option>
         <option value="CHILIE">CHILIE</option>
         <option value="ARGENTINE">ARGENTINE</option>
         </select>
         <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
         <?php
         $Val=($QuantiteProduit-$QuantiteV);
         echo '

         <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
         <input type="Tel" name="tel" placeholder="Numero telephone">
         <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
         <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
         <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
         <input type="submit" name="Achat" value="ACHATER" id="bouton">
         </form>';
         echo'</div>';
           }

     }
     }
}


//=======================================================================================================

   if (isset($_POST['Categorie'])) {
     $Categoriechoix=$_POST['choix'];


       if ($_POST['choix']=="all") {
         $VoirProduit=$conn->query("SELECT * FROM produit ");
         while ($ProduitCode=$VoirProduit->fetch()) {
           $CodeProduit=$ProduitCode['CodeProduit'];
           $PrixProduit=$ProduitCode['PrixUnitaire'];
           $QuantiteProduit=$ProduitCode['QuantiteProduit'];
             $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
           while ($Diminuer=$QuantiteVendue->fetch()) {
             $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

           }
           $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
           while ($share=$TextProduitShare->fetch()) {
             $ExiteCode=$share['Agent'];
           }
           if (($QuantiteProduit-$QuantiteV)>0) {
             # code...
             echo'<div class="col-md-3"';
        echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
         .'<form method="post" action="">';
         ?>

         <select name="choix">"

         <option value="Haiti">HAITI</option>
         <option value="USA">USA</option>
         <option value="BRESIL">BRESIL</option>
         <option value="CHILIE">CHILIE</option>
         <option value="ARGENTINE">ARGENTINE</option>
         </select>
         <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
         <?php
         $Val=($QuantiteProduit-$QuantiteV);
         echo '

         <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
         <input type="Tel" name="tel" placeholder="Numero telephone">
         <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
         <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
         <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
         <input type="submit" name="Achat" value="ACHATER" id="bouton">
         </form>';
         echo'</div>';
           }

     }
   }

     else{
         echo "Categorie".$Categoriechoix."<br>";
         $VoirProduit=$conn->query("SELECT * FROM produit WHERE Categorie='$Categoriechoix' ");
         while ($ProduitCode=$VoirProduit->fetch()) {
           $CodeProduit=$ProduitCode['CodeProduit'];
           $PrixProduit=$ProduitCode['PrixUnitaire'];
           $QuantiteProduit=$ProduitCode['QuantiteProduit'];
             $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
           while ($Diminuer=$QuantiteVendue->fetch()) {
             //$CodeProduitVendu=$Diminuer['CodeProduit'];
             $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

           }
           $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
           while ($share=$TextProduitShare->fetch()) {
             $ExiteCode=$share['Agent'];
           }
           if (($QuantiteProduit-$QuantiteV)>0) {
             # code...
             echo'<div class="col-md-3"';
        echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
         .'<form method="post" action="">';
         ?>

         <select name="choix">"

         <option value="Haiti">HAITI</option>
         <option value="USA">USA</option>
         <option value="BRESIL">BRESIL</option>
         <option value="CHILIE">CHILIE</option>
         <option value="ARGENTINE">ARGENTINE</option>
         </select>
         <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
         <?php
         $Val=($QuantiteProduit-$QuantiteV);
         echo '

         <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
         <input type="Tel" name="tel" placeholder="Numero telephone">
         <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
         <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
         <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
         <input type="submit" name="Achat" value="ACHATER" id="bouton">
         </form>';
         echo'</div>';
           }

     }
     }
   }else{
     $VoirProduit=$conn->query("SELECT * FROM produit ");
     while ($ProduitCode=$VoirProduit->fetch()) {
       $CodeProduit=$ProduitCode['CodeProduit'];
       $PrixProduit=$ProduitCode['PrixUnitaire'];
       $QuantiteProduit=$ProduitCode['QuantiteProduit'];
         $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
       while ($Diminuer=$QuantiteVendue->fetch()) {
         $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

       }
       $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
       while ($share=$TextProduitShare->fetch()) {
         $ExiteCode=$share['Agent'];
       }
       if (($QuantiteProduit-$QuantiteV)>0) {
         # code...
         echo'<div class="col-md-3"';
    echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
     .'<form method="post" action="">';
     ?>

     <select name="choix">"

     <option value="Haiti">HAITI</option>
     <option value="USA">USA</option>
     <option value="BRESIL">BRESIL</option>
     <option value="CHILIE">CHILIE</option>
     <option value="ARGENTINE">ARGENTINE</option>
     </select>
     <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
     <?php
     $Val=($QuantiteProduit-$QuantiteV);
     echo '

     <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
     <input type="Tel" name="tel" placeholder="Numero telephone">
     <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
     <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
     <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
     <input type="submit" name="Achat" value="ACHATER" id="bouton">
     </form>';
     echo'</div>';
       }

 }
   }

//===========================================================
   } else{

      $CodeAgent="Aucun";
      $CodeShare="Aucun";
         $VoirProduit=$conn->query("SELECT * FROM produit ");
         while ($ProduitCode=$VoirProduit->fetch()) {
           $CodeProduit=$ProduitCode['CodeProduit'];
           $PrixProduit=$ProduitCode['PrixUnitaire'];
           $QuantiteProduit=$ProduitCode['QuantiteProduit'];
             $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
           while ($Diminuer=$QuantiteVendue->fetch()) {
             //$CodeProduitVendu=$Diminuer['CodeProduit'];
             $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

           }
           $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
           while ($share=$TextProduitShare->fetch()) {
             $ExiteCode=$share['Agent'];
           }

           if (($QuantiteProduit-$QuantiteV)>0) {
             # code...

                  echo'<div class="col-md-3"';
             echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes +Shipping:<br> Quantite: ".($QuantiteProduit-$QuantiteV)
              .'<form method="post" action="">';
              ?>

              <select name="choix">"

              <option value="Haiti">HAITI</option>
              <option value="USA">USA</option>
              <option value="BRESIL">BRESIL</option>
              <option value="CHILIE">CHILIE</option>
              <option value="ARGENTINE">ARGENTINE</option>
              </select>
              <input type="Tel" name="Quantite" placeholder="Qte..." size="5"><br>
              <?php
              $Val=($QuantiteProduit-$QuantiteV);
              echo '

              <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br>
              <input type="Tel" name="tel" placeholder="Numero telephone">
              <input type="hidden" name="QuantiteRestant" value="'.$Val.'">
              <input type="hidden" name="codeshareproduit" value="'.$CodeProduit.'">
              <input type="hidden" name="prixshareproduit" value="'.$PrixProduit.'">
              <input type="submit" name="Achat" value="ACHATER" id="bouton">
              </form>';
              echo'</div>';
           }

     }

   }

      if (isset($_POST['Achat']) ) {
            $PrixProduit=$_POST['prixshareproduit'];
            $CodeProduit=$_POST['codeshareproduit'];
            $QuantiteRestant=$_POST['QuantiteRestant'];
            $tel=$_POST['tel'];
            $rue=$_POST['rue'];
            $choix=$_POST['choix'];

            if($choix=="Haiti"){
              $FraisDeLivraison=20;
            }
            if($choix=="CHILIE"){
              $FraisDeLivraison=120;
            }
            if($choix=="USA"){
              $FraisDeLivraison=150;
            }
            if($choix=="BRESIL"){
              $FraisDeLivraison=60;
            }
            if($choix=="ARGENTINE"){
              $FraisDeLivraison=65;
            }
            $Quantite=$_POST['Quantite'];

            $AdressCompet=$rue.", ".$choix;


              if (isset($_POST['Achat']) and !empty($Quantite) and !empty($rue)  and !empty($tel)) {
                if ($QuantiteRestant>=$Quantite) {
                  $Montant=$PrixProduit*$Quantite;

                  $Mon=$QuantiteRestant*$PrixProduit;

                  $Vente="INSERT INTO vente( CodeShare ,Zone,Quantite,Montant,FraisDeLivraison,CodeProduit,Telephone)
                  VALUES('$CodeShare','$AdressCompet','$Quantite','$Montant','$FraisDeLivraison','$CodeProduit','$tel')";
                  $conn->exec($Vente);
                  $_SESSION['ank']=null;
                  $F=$Montant+$FraisDeLivraison;

                  //header("location:https://cashmobile.online/main/pay?to=banj&amount=".$F."&description=PANYEN-an-NOU");
                  //header('location:https://cashmobile.online/main/pay/?to=banj&amount=50&description=Achat%20Prestige');

                }else {
                  ?>
                  <script> alert("Nous n'avons pas ce quantite en stock")</script>
                  <?php
                }
                //  header('location:Deconnection.php');
              }else{
                ?>
                <script> alert("Achat a pa fet")</script>
                <?php
              }

              $conn=null;
          }


 ?>
 </div>;
 </div>;
 <footer>
 	<div class="container-fluid">
 		<div class="row">
 			<div class="col-md-12">
 			<p><img src="img/logo2.png" width="40%"></p>
 			<P>PANYEN AN NOU 2019</P>
 		</div>

 		</div>
 	</div>
 </footer>
</body>

</html>
