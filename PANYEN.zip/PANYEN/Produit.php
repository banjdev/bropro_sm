
<html>
<head><title></title>
	<meta charset="utf-8">
  <meta http-equiv= »Content-Type » content= »text/html; charset=utf-8″ />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link href="css/mdb.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
	<div class="container-fluid">
				<div class="row">
				<div class="col-md-12">
<?php
  $CodeFournisseur=$_SESSION['Code'];
  if ($_SESSION['Tache']=='Fournisseur' and $_SESSION['parametre']=='pro1') {//Ajourter un produit
    ?>
    <!---ajoute produit par le fourniseur-->
    <div id="Produit">
      <form method="post" action="" enctype="multipart/form-data">
        <input  type="text" name="NomProduit"  size="20" maxlength="20" placeholder="le nom du produit" required><br>
        <fieldset>
          Categorie: <input type="RADIO" name="radio" value="Choix" onclick="pm();">Choix
          <input type="RADIO" name="radio" value="NChoix" onclick="pp();">Nouvelle
          <div id="pm"> Selecionner: <select name="choixSelect">
          <?php
            include('ConnexionDataBase.php');
              $Categorie=$conn->query("SELECT distinct Categorie FROM produit WHERE CodeFournisseur='$CodeFournisseur' ORDER BY Categorie ASC ");
              while ($Cata=$Categorie->fetch()) {
                echo"<option VALUE='".$Cata['Categorie']."'>".$Cata['Categorie']."</option><br>";
              }
            $conn=null;
          ?>
          </select>
          </div>
          <div id="pp">
            <input  type="text" name="NChoix" size="20" maxlength="15" placeholder="Nouvelle Categorie">
          </div>

        </fieldset>
        <textarea name="Description" id="Description"  placeholder="Description" required></textarea><br>
        <input  type="file" name="image"><br>
        <input type="number" name="PrixUnitaire" id="PrixUnitaire" size="9" placeholder="Prix Unitaire" required> HT<br>
        <input type="submit" name="Enregistrer" value="Enregistrer">
      </form>
    </div>
  </div>
    <script type="text/javascript">

    function pm (){
        document.getElementById("pm").style.display = "block";
        document.getElementById("pp").style.display = "none";
    }
    function pp (){
        document.getElementById("pm").style.display = "none";
        document.getElementById("pp").style.display = "block";
    }

    </script>
  </div>
</div>

    <?php
  }

  include('ConnexionDataBase.php');
      if (isset($_POST['Enregistrer']) and $_SESSION['Tache']=="Fournisseur" and !empty($_POST['radio'])) {//

        require 'Photo.php';
        $upload=new Photo();
        $NomProduit=htmlspecialchars($_POST['NomProduit']);
        $PhotoProduits=$_FILES['image']['name'];

        $Description=htmlspecialchars($_POST['Description']);
        $radio=htmlspecialchars($_POST['radio']);
        //Session de Reanregistrement

        //$Image=$_POST['Image'];
        $PrixUnitaire =htmlspecialchars($_POST['PrixUnitaire']);

        $AutomatiqueCodeProduit=substr($NomProduit,0,5).$CodeFournisseur;
        $EviterDoubleon=$conn->query("SELECT * FROM produit WHERE CodeProduit='$AutomatiqueCodeProduit' ");
        while ($Double=$EviterDoubleon->fetch()) {
          $Recuperation=$Double['CodeProduit'];
        }

        if($radio=="NChoix"){
          $choixSelect=htmlspecialchars($_POST['NChoix']);
        }else{
          $choixSelect=$_POST['choixSelect'];
        }

        if (!empty($NomProduit) && !empty($Description) && !empty($CodeFournisseur) && !empty($PrixUnitaire)) {
          if (!isset($Recuperation) && !empty($Categorie)) {
            $upload->FonctionPhoto($_FILES);

            $temp=$_FILES['image']['tmp_name'];
            $folder="img/Produits";
            //echo "Temp: ".$temp;
            //echo "<br>Le Nom du Fichier: ".$PhotoProduits;
            $PrixUnitaireTraite=$PrixUnitaire+$PrixUnitaire*0.1;
            if (move_uploaded_file($temp, $folder.'/'.$PhotoProduits)) {
              if (!empty($choixSelect)) {
                # code...
              }else{
                ?>
                <script>alert("Vueiller Cliquer sur le bouton radio pour valider votre preference");</script>
                <?php
              }
              $Doubleon=$conn->query("Select * From produit WHERE Image='$PhotoProduits' or NomProduit='$NomProduit'");
              while ($gere=$Doubleon->fetch()) {
                $Image=$gere['Image'];
              }
              if (!isset($Image)) {
                $EntrerProduit="INSERT INTO Produit(CodeProduit,NomProduit,Description,CodeFournisseur,PrixUnitaire,Categorie,Image)
                VALUE('$AutomatiqueCodeProduit','$NomProduit','$Description','$CodeFournisseur','$PrixUnitaireTraite','$choixSelect','$PhotoProduits')";
                $conn->exec($EntrerProduit);
                move_uploaded_file($temp, $folder.'/'.$PhotoProduits);
                ?>
                <script>alert("Votre Produit est reangistre");</script>
                  <script>alert("Ce fichier est transporte avec succes dans le Repertoire");</script>
                <?php
              }
            }
              else{
              ?>
              <script>alert("Votre produit n'est pas reanjistre");</script>
                <script>alert("Un Erreur est Produit lors dela transportation du fichier");</script>

              <?php
              }
          }else{
            echo "Vous Avez deja Ce produit";
          }
        }
        $conn=null;
      }
      //=================================================================Voir les Produits========================================
      if (($_SESSION['Tache']=='Fournisseur' || $_SESSION['Tache']=='Argent') and $_SESSION['parametre']=='pro') {


        include('ConnexionDataBase.php');
          echo "<form id='fpro' method='post' action=''>";
          if ($_SESSION['Tache']=='Fournisseur' ) {
            $Categorie=$conn->query("SELECT distinct Categorie FROM produit WHERE CodeFournisseur='$CodeFournisseur' ORDER BY Categorie ASC");
          }else{
            $Categorie=$conn->query("SELECT distinct Categorie FROM produit ORDER BY Categorie ASC ");
          }

            echo "<SELECT name='choix'>";
            echo "<option VALUE='all'>All</VALUE>";
              while ($Cata=$Categorie->fetch()) {
                echo"<option VALUE='".$Cata['Categorie']."'>".$Cata['Categorie']."</option><br>";
              }
            echo "</SELECT>";
            echo "<input type='submit' name='Categorie' value='Selectionner' id='bouton'>";
          echo "</form>";

          //===============Action sur le boutton====================================
          if (isset($_POST['Categorie'])) {
            $Categorie=$_POST['choix'];
            if($Categorie=="all"){//seleksyone all
              echo'<div class="container-fluid id="prodwi">
                    <div class=row>';
              if ($_SESSION['Tache']=='Fournisseur') {//si se yon fourniseur
                $VoirProduit=$conn->query("SELECT * FROM produit WHERE CodeFournisseur='$CodeFournisseur' ");
                while ($ProduitCode=$VoirProduit->fetch()) {
                  $CodeProduit=$ProduitCode['CodeProduit'];
                    $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];//Somme de quantite de produits Vendus

                  }
                  $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
                  while ($share=$TextProduitShare->fetch()) {
                    $ExiteCode=$share['Agent'];
                  }

                  echo'<div class="col-md-3">';
                  echo'<div id="prodwi">';
                  echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br/> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs <br>Activation Du Produit: ".$ProduitCode['Valider']."<br>Nombre de Agent: ".$ExiteCode." Agent";
                  echo '</div>';
                  echo'</div>';

                }
              }//fin pou pati all pou fournisseur an
              else{//si se yon ajan ou ye
                $VoirProduit=$conn->query("SELECT * FROM produit ");

                while ($ProduitCode=$VoirProduit->fetch()) {
                  $CodeProduit=$ProduitCode['CodeProduit'];
                    $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");

                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];

                  }
                  $CodeShareProduitTable=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrs.,;èÈtuvwxyz@#$%^&*()-_![]{}?/\|'),0,30);
              if (($ProduitCode['QuantiteProduit']-$QuantiteV)>=1 and $ProduitCode['Valider']=="OUI") {
                  echo'<div class="col-md-4">';
                  echo'<div id="prodwi">';
                  echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs".'
                   <br/><div class="fb-like" data-href="http://192.168.137.1/panyen/Achat.php?ag='.$_SESSION['Code'].'&amp;prod='.$CodeProduit.'&amp;sh='.$CodeShareProduitTable.'" data-width="400" data-layout="standard" data-action="recommend" data-size="small" data-show-faces="true" data-share="true"></div>';
                   echo '</div>';
                   echo'</div>';
                }

                  //echo "Mw Antre la ".$CodeProduit;


                }
              }
              echo '</div>';
              echo'</div>';
            }else {
              echo'<div class="container-fluid id="prodwi">
                    <div class=row>';
              if ($_SESSION['Tache']=='Fournisseur') {
                $VoirProduit=$conn->query("SELECT * FROM produit WHERE CodeFournisseur='$CodeFournisseur' and Categorie='$Categorie' ");
                while ($ProduitCode=$VoirProduit->fetch()) {
                  $CodeProduit=$ProduitCode['CodeProduit'];
                    $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");
                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];

                  }
                  $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
                  while ($share=$TextProduitShare->fetch()) {
                    $ExiteCode=$share['Agent'];
                  }
                  echo'<div class="col-md-4">';
                  echo'<div id="prodwi">';
                  echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs <br>Activation Du Produit: ".$ProduitCode['Valider']."<br>Nombre de Agent: ".$ExiteCode." Agent";
                  echo '</div>';
                  echo'</div>';
                }
              }else{//Agent
                $VoirProduit=$conn->query("SELECT * FROM produit WHERE Categorie='$Categorie' ");
                while ($ProduitCode=$VoirProduit->fetch()) {
                  $CodeProduit=$ProduitCode['CodeProduit'];
                    $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");

                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];

                  }
                  $CodeShareProduitTable=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrs.,;èÈtuvwxyz@#$%^&*()-_![]{}?/\|'),0,30);
                  if (($ProduitCode['QuantiteProduit']-$QuantiteV)>=1 and $ProduitCode['Valider']=="OUI") {
                    echo'<div class="col-md-4">';
                    echo'<div id="prodwi">';
                    echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs".'
                <br/><div class="fb-like" data-href="http://192.168.137.1/panyen/Achat.php?ag='.$_SESSION['Code'].'&amp;prod='.$CodeProduit.'&amp;sh='.$CodeShareProduitTable.'" data-width="400" data-layout="standard" data-action="recommend" data-size="small" data-show-faces="true" data-share="true"></div>';
                    echo '</div>';
                    echo'</div>';
                }


              }
              }
              echo '</div>';
              echo'</div>';
            }
          }//Automatique
          else {
            echo'<div class="container-fluid id="prodwi">
                  <div class=row>';
            if ($_SESSION['Tache']=='Fournisseur') {

              $VoirProduit=$conn->query("SELECT * FROM produit WHERE CodeFournisseur='$CodeFournisseur' ");
              while ($ProduitCode=$VoirProduit->fetch()) {
                $CodeProduit=$ProduitCode['CodeProduit'];
                $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");

                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];

                  }
                  $TextProduitShare=$conn->query("SELECT count(s.CodeProdutShare) as Agent,p.CodeProduit FROM share s, produit p WHERE s.CodeProdutShare='$CodeProduit' and p.CodeProduit='$CodeProduit' ");
                  while ($share=$TextProduitShare->fetch()) {
                    $ExiteCode=$share['Agent'];
                  }
                  echo'<div class="col-md-4">';
                  echo'<div id="prodwi">';
                  echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs <br>Activation Du Produit: ".$ProduitCode['Valider']."<br>Nombre de Agent: ".$ExiteCode." Agent";
                  echo '</div>';
                  echo'</div>';
              }

            }else{//Argent
              $VoirProduit=$conn->query("SELECT * FROM produit ");
                while ($ProduitCode=$VoirProduit->fetch()) {
                  $CodeProduit=$ProduitCode['CodeProduit'];
                  $QuantiteVendue=$conn->query("SELECT sum(Quantite) as Reduction FROM vente WHERE CodeProduit='$CodeProduit' ");

                  while ($Diminuer=$QuantiteVendue->fetch()) {
                    //$CodeProduitVendu=$Diminuer['CodeProduit'];
                    $QuantiteV=$Diminuer['Reduction'];

                  }
                  //echo "Code Produit".$CodeProduit;
                  $CodeShareProduitTable=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrs.,;èÈtuvwxyz@#$%^&*()-_![]{}?/\|'),0,30);
                  if (($ProduitCode['QuantiteProduit']-$QuantiteV)>=1 and $ProduitCode['Valider']=="OUI") {
                      echo'<div class="col-md-4">';
                      echo'<div id="prodwi">';
                        echo "<br>".'<img src="img/Produits/'.$ProduitCode['Image'].'"'." class='prphoto'/><br> ".$ProduitCode['NomProduit']."<br>Commentaire: ".$ProduitCode['Description']."<br>Prix Unitaire: ".$ProduitCode['PrixUnitaire']." Gdes<br> Quantite: ".($ProduitCode['QuantiteProduit']-$QuantiteV)." Pcs".'
                      <br/><div class="fb-like" data-href="http://192.168.137.1/panyen/Achat.php?ag='.$_SESSION['Code'].'&amp;prod='.$CodeProduit.'&amp;sh='.$CodeShareProduitTable.'" data-width="400" data-layout="standard" data-action="recommend" data-size="small" data-show-faces="true" data-share="true"></div>';
                      echo '</div>';
                      echo'</div>';
                  }



              }
              echo '</div>';
              echo'</div>';
            }

          }
      }
      ?>
    </body>
    </html>
