


<?php
require'fonction.php';
//$RecherchFonction=new fonction();
//connnexion menbre
if (isset($_POST['connexion'])) {
  $Pseudo=htmlspecialchars($_POST['Pseudo']);
  $Password=htmlspecialchars($_POST['password']);
  include('ConnexionDataBase.php');
    $Connexion=$conn->query("SELECT * FROM compte WHERE Pseudo='$Pseudo' and Password='$Password' ");
    while($row=$Connexion->fetch()){
		    $Pseudo1=$row['Pseudo'];
			  $Password1=$row['Password'];
			  $CodePersonne=$row['Code'];
			  $TachePersonne=$row['Tache'];
			  $NomComplet=$row['Nom_Complet'];
				$Adress=$row['Adress'];
				$Email=$row['Email'];
				$Tel=$row['Tel'];
				$Pseudo=$row['Pseudo'];
				$Password=$row['Password'];
				$Activation=$row['Activation'];
				$CompteBanquaire=$row['CompteBanquaire'];
				$Photo =$row['Photo'];
  	}
    if (!empty($Pseudo1) and !empty($Password1)) {
			    	if ($Pseudo==$Pseudo1 and $Password==$Password1 ) {
			       	Connect($CodePersonne,$TachePersonne,$NomComplet,$Adress,$Email,$Tel,$Pseudo,$Password,$Activation,$CompteBanquaire,$Photo);

			    	}
			    	else{
	       			?>
	       			<script type="text/javascript">alert("Nou paka konektew paske ou pa ko inskri")</script>
		       		 <?php
		    		}
				}
			    else{
	       			?>
	       			<script type="text/javascript">alert("Nou paka konektew paske ou pa ko inskri")</script>
		       		 <?php
		    		}

}
 ?>
 <!DOCTYPE HTML>
 <html>
 <head><title>test intro</title>
 	<meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <script src="js/jquery-3.3.1.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
 	<link rel="stylesheet" href="css/bootstrap.min.css">
 	<link href="css/mdb.min.css" rel="stylesheet">
 	<link rel="stylesheet" type="text/css" href="css/style.css"/>
 </head>
 <body>
  <div class="container-fluid">
    <div class="row" id="connexion">
    				<div class="col-md-6">
    					<p><img src="img/logo.png" width="90%"/></p>
    				</div>
    				<div id="info_C" class="col-md-6">

    					<form method="post" action="">
    						<img src="img/login.png"/>
    						<input type="text" name="Pseudo" id="Pseudo" size="20" maxlength="20" placeholder="Pseudo" required>
    						<input type="password" name="password" id="password" placeholder="password" required>
    						<input id="b_konek" type="submit" name="connexion" value="Connectez-vous">
    					</form>
    				</div>
    </div>

    	<div class="row" id="inskri">
    		<div class="col-md-12" id="ins">
          <h1>Inscription</h1>
    			<div id="Inscription">
    				<form method="post" action="" enctype="multipart/form-data">
    					Nom & Prénom<br/><input type="text" name="Nom" id="Nom" size="30" maxlength="50" placeholder="Nom Complet" required><br>
    					Adresse<br/><input type="text" name="Adress" id="Adress" size="30" maxlength="50" placeholder="Votre Adress" required><br>
    					Email<br/><input type="email" name="Email" id="email" size="30" maxlength="25" placeholder="Email..." required>
    					<?php
              if (isset($_POST['envoyer'])) {
				        require 'Photo.php';//importer le fichier
        				$upload = new Photo();//instancier la Class du fichier

        				$Password=htmlspecialchars($_POST['password']);
        				$Pseudo=htmlspecialchars($_POST['Pseudo']);
        				$Nom=htmlspecialchars($_POST['Nom']);
        				$Tache=$_POST['choix'];
        				$Adress=htmlspecialchars($_POST['Adress']);
        				$Tel=htmlspecialchars($_POST['Telephone']);
        				$Email=htmlspecialchars($_POST['Email']);
        				$CompteBanquaire=htmlspecialchars($_POST['CompteBanquaire']);
        				$NomFile=$_FILES['image']['name'];

        				//Gestion de la Code automatique   (une fonction gere cete partie de code)
        				$mel=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz@#$%^&*()-_![]{}?/\|'),0,3);
        			}
    						if (isset($_POST['envoyer'])){
    							$Mail=$conn->query("SELECT Email FROM compte WHERE Email='$Email'");
    							while ($CheckMail=$Mail->fetch()) {
    								$MailExiste=$CheckMail['Email'];
    							}
    							if (isset($MailExiste)) {
    								echo "<em> imèl sa ekziste deja</em>";
    							}
    						}

    					?><br/>
    					Telephone<br/><input type="tel" name="Telephone" id="tel" size="30" maxlength="20" placeholder="Telephone:...." required>
    					<?php

    						if (isset($_POST['envoyer'])){
    							$Telp=$conn->query("SELECT Tel FROM compte WHERE Tel='$Tel'");
    							while ($CheckTel=$Telp->fetch()) {
    								$TelExiste=$CheckTel['Tel'];
    							}
    							if (isset($TelExiste)) {
    								echo "<em> nimewo sa ekziste deja</em>";
    							}
    						}

    						?>
    						<br>
    						Type:
    						<SELECT name="choix" id="choix">
    							<OPTION VALUE="none"></OPTION>
    							<OPTION VALUE="Fournisseur">Vente</OPTION>
    							<OPTION VALUE="Argent">Klik Pam</OPTION>
    						</SELECT><br>
    						Photo
    						<input  type="file" name="image" size="10" required>
    						<?php

    							if(isset($_POST['envoyer'])){
    									//--------------------------------CountFonction----------------------------------------
    								$Double=$conn->query("SELECT count(Code) as Nombre FROM compte");
    								while ($CheckCode=$Double->fetch()){
    									$TextCode=$CheckCode['Nombre']+1;
    								}
                    $Tache=$_POST['choix'];
    								if ($Tache=="none") {
    									echo "<em>Chwazi yon tip</em>";
    								}
                    //$Nom=$_POST['Nom'];
                    //$mel=substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz@#$%^&*()-_![]{}?/\|'),0,3);
    								$Code=substr(strtoupper($Nom),0,3).substr(strtoupper($Tel),0,3)."-".$mel.$TextCode;
    								if ($Tache=="Argent") {
    									$Activation="OUI";
    								}else{
    									$Activation="NON";//L'administraction qui aura doit d'activer le Fournisseur
    								}
    							}

    						?><br>
    						Compte Banquaire<br/><input type="text" name="CompteBanquaire" id="CompteBanquaire" size="30" maxlength="30" placeholder="Votre Compte Banquaire..." required><br>
    						<?php

    							if (isset($_POST['envoyer'])) {
    						 		$CompteBanquaireCheck=$conn->query("SELECT CompteBanquaire FROM compte WHERE CompteBanquaire='$CompteBanquaire'");
    								while ($CheckCompteBanquaire=$CompteBanquaireCheck->fetch()) {
    									$CompteBanquaireExiste=$CheckCompteBanquaire['CompteBanquaire'];
    								}
    								if (isset($CompteBanquaireExiste)) {
    									echo "<em> itilize kont bank paw pouw ka fe aktivasyon an</em>";
    								}
    						 	}


    						?>
    						Pseudo<br/><input type="text" name="Pseudo" id="Pseudo" size="30" maxlength="20" placeholder="Pseudo..." required>
    						<?php

    							if (isset($_POST['envoyer'])){
    								$Pseudorep=$conn->query("SELECT Pseudo FROM compte WHERE Pseudo='$Pseudo'");
    								while ($CheckPseudo=$Pseudorep->fetch()) {
    									$PseudoExiste=$CheckPseudo['Pseudo'];
    								}
    								if (isset($PseudoExiste)) {
    									echo "<em> Pseudo sa ekziste deja</em>";
    								}

    							}

    						?><br/>
    						Password<br/><input type="password" name="password" id="password" size="30" maxlength="30" placeholder="Mot de pass..." required><br>
    						<input id="b_konek" type="submit" name="envoyer" value="ENREGISTRER">
    					</form>
    					<?php

    					 	if(isset($_POST['envoyer'])) {
    							$upload->FonctionPhoto($_FILES);

    							$temp=$_FILES['image']['tmp_name'];
    							$folder="img/ImageCompte";

    							if (move_uploaded_file($temp, $folder.'/'.$NomFile) and !isset($MailExiste) AND !isset($TelephoneExiste) AND !isset($PseudoExiste) and $Tache!="none" and !isset($CompteBanquaireExiste) And isset($temp) and !empty($_FILES['image']['name'])) {
    							$sql = "INSERT INTO compte (Code,Nom_Complet,Adress,Email,Tel,Pseudo,Password,Tache,Activation,CompteBanquaire,Photo)
    							VALUES ('$Code','$Nom','$Adress','$Email','$Tel','$Pseudo', '$Password','$Tache','$Activation','$CompteBanquaire','$NomFile') ";
    							$conn->exec($sql);
    							$conn=null;
    							Connect($Code,$Tache,$Nom,$Adress,$Email,$Tel,$Pseudo,$Password,$Activation,$CompteBanquaire,$NomFile);
    							//echo "<em>ou anrejistre</em>";

    						?>
    							<!--<script>alert("ou anrejistre");</script>-->
    						<?php

    								//echo "<br/> ".$Chanp;
    							move_uploaded_file($temp, $folder.'/'.$NomFile);
    							}
    							else{

    							?>
    							<script>alert("anrejstreman pa fèt");</script>

    							<?php

    							}
    						}
    						$conn=null;
    			    	?>
    				</div>
    			</div>
    	</div>
    </div>
</div>
   <footer>
   <div class="container-fluid">
     <p>PANYEN AN NOU</p>
   </div>
   </footer>
</body>
