<?php
try {
    $conn= new PDO('mysql:host=localhost;dbname=panyenbd','root','Panyen@12');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
    echo 'Echec : ' .$e->getMessage();
}
?>
