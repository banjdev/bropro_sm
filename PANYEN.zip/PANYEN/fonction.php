<?php

include('ConnexionDataBase.php');
//class fonction{
  function Connect($CodePersonne,$TachePersonne,$NomComplet,$Adress,$Email,$Tel,$Pseudo,$Password,$Activation,$CompteBanquaire,$Photo){
    session_start();
			include('ConnexionDataBase.php');
				$CodePersonneConnect=$CodePersonne;
				$_SESSION['Code']=$CodePersonne;
						$_SESSION['Tache']=$TachePersonne;
						$_SESSION['NomComplet']=$NomComplet;
						$_SESSION['Adress']=$Adress;
						$_SESSION['Email']=$Email;
						$_SESSION['Tel']=$Tel;
						$_SESSION['Pseudo']=$Pseudo;
						$_SESSION['Password']=$Password;
						$_SESSION['Activation']=$Activation;
						$_SESSION['CompteBanquaire']=$CompteBanquaire;
						$_SESSION['Photo']=$Photo;

						$Connecter="INSERT INTO control(CodePersonne,Action)
						VALUE('$CodePersonneConnect','Connecter')";
						$conn->exec($Connecter);


						$Retrait=$conn->query("SELECT sum(Montant) as RetraitFaite FROM retrait WHERE CodePersonne='$CodePersonne' ");
						while($RetraitMonant=$Retrait->fetch()){
							$TotalRetrait=$RetraitMonant['RetraitFaite'];
						}
						if ($_SESSION['Tache']=="Fournisseur") {

							$Produit=$conn->query("SELECT v.CodeProduit,sum(v.Montant) as SumVente,p.CodeFournisseur, p.CodeProduit, v.CodeShare FROM vente v, produit p WHERE p.CodeFournisseur='$CodePersonne' and p.CodeProduit=v.CodeProduit");
							while ($Recherche=$Produit->fetch()) {
								$Montan=$Recherche['SumVente'];
							}
							$solde= $Montan*0.9;
						}
						if ($_SESSION['Tache']=="Argent") {
							$Produit=$conn->query("SELECT s.CodeProdutShare,s.CodeAgent, sum(v.Montant) as SumVente, s.CodeAgent,p.CodeProduit, s.CodeShare,v.CodeShare FROM vente v, produit p, share s WHERE s.CodeAgent='$CodePersonne' and p.CodeProduit=s.CodeProdutShare and s.CodeShare=v.CodeShare");
							while ($Recherche=$Produit->fetch()) {
								$Montan=$Recherche['SumVente'];
							}
							$solde= $Montan*0.05;
						}
						if ($_SESSION['Tache']=="Administration") {
							$Produit=$conn->query("SELECT sum(Montant) as SumVente, CodeShare FROM vente WHERE CodeShare='Aucun' ");
							while ($Recherche=$Produit->fetch()) {
								$Montan=$Recherche['SumVente'];
							}
							$solde1= $Montan*0.1;//sa poko mache

						$Produit=$conn->query("SELECT sum(Montant) as SumVente, CodeShare FROM vente WHERE CodeShare!='Aucun'  ");
							while ($Recherche=$Produit->fetch()) {
								$Montan=$Recherche['SumVente'];
							}
							$solde2= $Montan*0.05;//sa poko mache

						$Produit=$conn->query("SELECT sum(FraisDeLivraison) as SumVente FROM vente ");
							while ($Recherche=$Produit->fetch()) {
								$Montan=$Recherche['SumVente'];
							}
							$solde3=$Montan;
							$solde=$solde2+$solde1+$solde3;
						}


						$_SESSION['Montant']=($solde-$TotalRetrait)." Gdes";
						$conn=null;
            //echo "OU KONEKTE";
								//header("location:Compte.php");
						header("location:Compte.php?ch=pro");
		}

    function MontantAjout($CodePersonne){
      include('ConnexionDataBase.php');
      $Retrait=$conn->query("SELECT sum(Montant) as RetraitFaite FROM retrait WHERE CodePersonne='$CodePersonne' ");
      while($RetraitMonant=$Retrait->fetch()){
        $TotalRetrait=$RetraitMonant['RetraitFaite'];
      }
      if ($_SESSION['Tache']=="Fournisseur") {

        $Produit=$conn->query("SELECT v.CodeProduit,sum(v.Montant) as SumVente,p.CodeFournisseur, p.CodeProduit, v.CodeShare FROM vente v, produit p WHERE p.CodeFournisseur='$CodePersonne' and p.CodeProduit=v.CodeProduit");
        while ($Recherche=$Produit->fetch()) {
          $Montan=$Recherche['SumVente'];
        }
        $solde= $Montan*0.9;
      }
      if ($_SESSION['Tache']=="Argent") {
        $Produit=$conn->query("SELECT s.CodeProdutShare,s.CodeAgent, sum(v.Montant) as SumVente, s.CodeAgent,p.CodeProduit, s.CodeShare,v.CodeShare FROM vente v, produit p, share s WHERE s.CodeAgent='$CodePersonne' and p.CodeProduit=s.CodeProdutShare and s.CodeShare=v.CodeShare");
        while ($Recherche=$Produit->fetch()) {
          $Montan=$Recherche['SumVente'];
        }
        $solde= $Montan*0.05;
      }
      if ($_SESSION['Tache']=="Administration") {
        $Produit=$conn->query("SELECT sum(Montant) as SumVente, CodeShare FROM vente WHERE CodeShare='Aucun' ");
        while ($Recherche=$Produit->fetch()) {
          $Montan=$Recherche['SumVente'];
        }
        $solde1= $Montan*0.1;//sa poko mache

      $Produit=$conn->query("SELECT sum(Montant) as SumVente, CodeShare FROM vente WHERE CodeShare!='Aucun'  ");
        while ($Recherche=$Produit->fetch()) {
          $Montan=$Recherche['SumVente'];
        }
        $solde2= $Montan*0.05;//sa poko mache

      $Produit=$conn->query("SELECT sum(FraisDeLivraison) as SumVente FROM vente ");
        while ($Recherche=$Produit->fetch()) {
          $Montan=$Recherche['SumVente'];
        }
        $solde3=$Montan;
        $solde=$solde2+$solde1+$solde3;
      }


      $_SESSION['Montant']=($solde-$TotalRetrait)." Gdes";
      $conn=null;
      //echo "OU KONEKTE";
          //header("location:Compte.php");
      header("location:Compte.php?ch=solde");
    }

    //Foction Menu



  //}

  function infoProduit($CodeProduitAchat,$QuantitePrimaire,$PrixUnitaire,$Image,$NomProduit,$Description,$CodeAChat,$CodeAgent){//
    include('ConnexionDataBase.php');

    $Vente=$conn->query("SELECT sum(Quantite) as Qte FROM vente WHERE CodeProduit='$CodeProduitAchat' ");
    while ($VenteInfo=$Vente->fetch()) {
      $QuantiteVendue=$VenteInfo['Qte'];
    }

    if (($QuantitePrimaire-$QuantiteVendue)>=1) {
      echo'  <div class="col-md-6 id="test">
            <div >';

      echo "<br>".'<img src="img/Produits/'.$Image.'"'." class='prphoto2'/><br> ".$NomProduit."<br>Commentaire: ".$Description."<br>Prix Unitaire: ".$PrixUnitaire." Gdes +Chipping:<br> Quantite: ".($QuantitePrimaire-$QuantiteVendue)
      .'<form method="post" action="">';
      ?>
      Pays: <select name="choix">"

      <option value="Haiti">HAITI</option>
      <option value="USA">USA</option>
      <option value="BRESIL">BRESIL</option>
      <option value="CHILIE">CHILIE</option>
      <option value="ARGENTINE">ARGENTINE</option>
      </select><br>
      <?php
      $Val=$QuantitePrimaire-$QuantiteVendue;

      echo 'Rue: <input type="text" name="rue" placeholder="#17A, rue Alliance, Delmas 33"><br/>
      Qte: <input type="number" name="Quantite" placeholder="Qte..." size="5"><br/>
      Tel: <input type="Tel" name="tel" placeholder="Numero telephone"><br>
      <input type="text" name="Numero" placeholder="Numero de Votre Compte de Payement...">
      <input type="hidden" name="codeshareproduit" value="'.$Val.'">
      <input type="hidden" name="codeshareproduit" value="'.$CodeProduitAchat.'">
      <input type="hidden" name="prixshareproduit" value="'.$PrixUnitaire.'">
      <input type="submit" name="ADD" value="ADD" id="bouton">
      ';
      echo'</div>';
      echo'</div>';
    }


    if (isset($_POST['ADD'])) {
      //echo "Add Produit: ".$_POST['codeshareproduit'];
      echo "$CodeAChat";
      echo "$CodeProduitAchat";
      $Test=$conn->query("SELECT * FROM Panye WHERE AchatCode='$CodeAChat' and CodeProduit='$CodeProduitAchat' ");
      while ($Doubleon=$Test->fetch()) {
        $AchatCode1=$Doubleon['AchatCode'];
      }
      if (!isset($AchatCode1)) {
        $Mon=$Val*$PrixUnitaire;
        $sql = "INSERT INTO Panye (AchatCode,CodeProduit,MontantAchat,AgentCode)
        VALUES ('$CodeAChat','$CodeProduitAchat','$Mon','$CodeAgent') ";
        //$conn->exec($sql);
        $conn=null;
      }
    }

    $conn=null;

  }

 ?>
