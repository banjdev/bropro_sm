<div class"container-fluid">
  <div class="row">
    <div class="col-md-12">

<?php
  require'fonction.php';
      $Code=$_SESSION['Code'];
      if ($_SESSION['parametre']=="param" || $_SESSION['parametre']=="photo") {
        echo'<div  id="parametre" >';
        echo'<div  id="infoparametre" >';
        echo "<a href='?ch=photo'>"."<img  src='img/ImageCompte/".$_SESSION['Photo']."'  class='pphoto' width=20%/><br/>Modifier L'image</a>";
        echo "<br><b>Compte:</b>".$_SESSION['Tache'];
        echo "<br><b>Nom Complet:</b>".$_SESSION['NomComplet'];
        echo "<br><b>Adress:</b>".$_SESSION['Adress'];
        echo "<br><b>Email:</b>".$_SESSION['Email'];
        echo "<br><b>Tel:</b>".$_SESSION['Tel'];
        //echo "<br><b>Pseudo:</b>************ ";
        //echo "<br><b>Password:</b>******** ";
        ?>
        <form method="post" action="">
          <input type="submit" id="bouton" name='FormeComfirmer' value="Modifier Le Mot de Pass">
        </form>
        <?php
        echo "<b>Activation:</b>".$_SESSION['Activation'];
        //echo "<br><b>Compte Banquaire:</b>************";
        echo "<br><b>Solde: ".$_SESSION['Montant']."</b>";

        //echo "<br>Code:".$_SESSION['Code'];


        ?>
        <!---<form method="post" action="">
          <input type="submit" name='FormeComfirmer' value="Modifier Le Mot de Pass">
        </form>-->
      <?php
      if (isset($_POST['FormeComfirmer'])) {
        echo "<form method='post' action=''>
          <input type='text' name='Pseudo' id='Pseudo' placeholder='Ansyen Pseudo' required/>
          <input type='password' name='password' id='password' placeholder='Ansyen Password' required>
          <input type='submit' name='BoutonChanger' id='bouton' value='Confirmation'>
          </form>";
      }
        if (isset($_POST['BoutonChanger']) and !empty($_POST['password']) and !empty($_POST['Pseudo'])) {
        //header("location:?ch=param");
          if ($_POST['password']==$_SESSION['Password'] and $_POST['Pseudo']==$_SESSION['Pseudo']) {
            echo "<form method='post' action=''>
              <input type='text' name='password1' id='password' placeholder='Nouvo Password' required>
              <input type='submit' name='Modifier' id='bouton'' value='ENREGISTRER'>
              </from>";
          }
        }


        if (isset($_POST['Modifier']) and !empty($_POST['password1'])) {
          $Pass=$_POST['password1'];

          include('ConnexionDataBase.php');
            $ModifierPassword=$conn->query("UPDATE compte SET Password='$Pass' WHERE Code='$Code'");
            $_SESSION['Password']=$Pass;
            ?>
            <div><script type="text/javascript">alert("Mode passe Modifier")</script></div>;
            <?php
          $conn=null;
        }
      }


        if ($_SESSION['parametre']=="password") {

          echo "<form method='post' action=''>
          <input type='text' name='Pseudo' id='Pseudo' placeholder='Ansyen Pseudo' required/>
          <input type='password' name='password' id='password' placeholder='Ansyen Password' required>
          <input type='submit' name='BoutonChanger' id='bouton' value='Confirmation'>
          </form>";


      }




      if ($_SESSION['parametre']=="photo" and !isset($_POST['FormeComfirmer']) AND !isset($_POST['BoutonChanger'])) {
        echo "<form method='post' action='' enctype='multipart/form-data'>
        <input type='file' name='image' size='1'>
        <input type='submit' name='changement' value='Changer Votre Profil' id='bouton'>
        </form>";
        if (isset($_POST['changement']) and !empty($_FILES['image']['name'])) {
          require 'Photo.php';
          $upload= new Photo();
          $upload->FonctionPhoto($_FILES);

          include('ConnexionDataBase.php');
            $id=$_SESSION['Code'];
            $image=$_FILES['image']['name'];
            $PhotoChanger=$conn->query("UPDATE compte SET Photo='$image' WHERE code='$id' ");
            $_SESSION['Photo']=$image;
            header("location:Compte.php?ch=param");
          $conn=null;

          $temp=$_FILES['image']['tmp_name'];
          $folder="img/ImageCompte";

          if (move_uploaded_file($temp, $folder.'/'.$image)) {
                    ?>
                      <script>alert("Ce fichier est tranporte avec succes dans le Repertoire");</script>
                    <?php
                      move_uploaded_file($temp, $folder.'/'.$image);
          }
          else{
                    ?>
                      <script>alert("Un Erreur est Produit lors de la transportation du fichier");</script>

                    <?php
          }

        }
      }
      //-- Fonction de récupération de l'adresse IP du visiteur
      /*function get_ip()
      {
          if ( isset ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) )
          {
              $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
          }
          elseif ( isset ( $_SERVER['HTTP_CLIENT_IP'] ) )
          {
              $ip  = $_SERVER['HTTP_CLIENT_IP'];
          }
          else
          {
              //$ip = $_SERVER['REMOTE_ADDR'];
              if(getenv('HTTP_X_FORWARDED_FOR'))
                $ip = getenv('HTTP_X_FORWARDED_FOR');
                elseif(getenv('HTTP_CLIENT_IP'))
                $ip = getenv('HTTP_CLIENT_IP');
                else
                $ip = getenv('REMOTE_ADDR');
          }
          return $ip;
          echo'</div>';

      }*/
      echo'</div>';
      echo'</div>';


      if ($_SESSION['parametre']=="solde") {
        echo '<div id="solde">';
        //echo 'Votre adresse IP est : ' . get_ip ();
        echo "<br>";
        ob_start();
        system("ipconfig /all");
        $mycom=ob_get_contents();
        ob_clean();
        $findme = "physique";
        $pmac = strpos($mycom, $findme);
        $mac=substr($mycom,($pmac),3417);
        //echo $mac;
        //les condition sont strick car desque vous antre les conditions conforme
        //password
        ?>
        <?php
              echo "<br><b><p class='kob' >Solde: ".$_SESSION['Montant']."</p></b>";
              if (!isset($_POST['boutonpassword'])) {
        ?>

        <form method="post" action="">
          <input type="password" name="password" size="30" placeholder="votre password" required>
          <input type="submit" id="bouton" name="boutonpassword" value="Valider">
        </form>
        <?php
      }
        if (isset($_POST['boutonpassword']) and !empty($_POST['password'])) {
          $Pseudo=$_SESSION['Pseudo'];
          $Password=$_POST['password'];
          include('ConnexionDataBase.php');
          $CheckPersonne=$conn->query("SELECT * FROM compte WHERE Pseudo='$Pseudo' and Password='$Password' ");
          while ($Pass=$CheckPersonne->fetch()) {
            $CodeText=$Pass['Code'];
          }
          if (isset($CodeText)) {
            if ($CodeText==$Code) {
              echo'<form method="post" action="">
                <input type="float" name="retrait" size="10" required>
                <input type="submit" id="bouton" name="bouttonRetrait" value="Retrait">
              </form>';
            }
          }else{
            header("loaction:Deconnection.php");
          }
        }include('ConnexionDataBase.php');
          if (isset($_POST['bouttonRetrait'])) {
            $Valeur=$_POST['retrait'];
            $montant=$_SESSION['Montant'];
            if ($montant >=$Valeur) {
                if($Valeur>=1){
                $AdressIP=$mac;

                $MontantRetrait="INSERT INTO retrait(CodePersonne,Montant,AdressIP)
                VALUES('$Code','$Valeur','$AdressIP')";
                $conn->exec($MontantRetrait);
                $conn=null;
                MontantAjout($Code);
                //$Montan=$_SESSION['Montant']-$Valeur;
              }
            }else {
              if ($_SESSION['Montant']<$_POST['retrait']) {
                echo "Ou pa ge tout kob sa<br>Montant ou se ".$_SESSION['Montant']."<br>Montant ou ap antre an se ".$Valeur;
              }
              if($_POST['retrait']<1) {
                echo "Li infereir a 1";
              }
            }
          }
          echo'</div>';
        }


      ?>

    </div>
  </div>
</div>
