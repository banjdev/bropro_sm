<?php
	session_start();
	$CodePersonne=$_SESSION['Code'];
	//$PAGE=$_SESSION['PAGE'];
	include('ConnexionDataBase.php');

		if (isset($_SESSION['Code'])) {
			if (isset($_GET['deconnexion'])) {
				$Deconnecter="INSERT INTO control(CodePersonne,Action)
				VALUE('$CodePersonne','Deconnecter')";
				$conn->exec($Deconnecter);
			}else{
				$Deconnecter="INSERT INTO control(CodePersonne,Action)
				VALUE('$CodePersonne','Page')";
				//$conn->exec($Deconnecter);
			}
		}

		//$sqldeconnection= $conn->query("UPDATE etudiant  SET ACTIF=0 WHERE ID='$id' ");
	$conn=null;
	$_SESSION =array();
	session_destroy();
	unset($_SESSION);
	header("location:Connexion.php");

?>
