<?php
	class Photo {

		function FonctionPhoto(array $infoFiles){
			$infoFiles=current($infoFiles);
			@set_time_limit(172800);//permet au code source de charge de gros fichier jusqu'a 2 jours

			$alloweExts= array("jpd", "jped", "gif", "png","jpg" );
			$extension=pathinfo($infoFiles['type'], PATHINFO_EXTENSION);//pour les extention du fichier (mp3, mp4 etc...)


			//$longueur=$_FILES['file']['lenght'];
			$name=$_FILES['image']['name'];
			$namesize=$_FILES['image']['size'] ;//kantite de byete
			$nameType=$_FILES['image']['type'];//video/image/audio/application(format)
			$temp=$_FILES['image']['tmp_name'];//referene
			$nameError=$_FILES['image']['error'];//Error
			if ($_FILES['image']['type']===$nameType && in_array($extension, $alloweExts)) {

				if (substr($nameType,0,5)==="image") {
					$folder="img/ImageCompte";
					$Chanp=substr($nameType,0,5);
				}
			}
		}
	}
	/**
	*
	*/


?>
