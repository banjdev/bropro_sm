<?php
	if ($_SESSION['Tache']!='Administration') {
		header("location:Deconnection.php");
	}
	if ($_SESSION['parametre']=="Confirm") {
		echo "Confirm";
		//voir les listes des fournisseurs et les accepter
		include('ConnexionDataBase.php');
		$Rechercher=$conn->query("SELECT * FROM compte WHERE Tache='Fournisseur' and Activation='NON'");
		while ($NON=$Rechercher->fetch()) {
			$CodeFournisseur=$NON['Code'];
			//echo "Code: ".$CodeFournisseur;
			echo "<br>".'<img src="img/ImageCompte/'.$NON['Photo'].'"'." width=10% class= animated bounceInDown/><br/>Nom Complet:  ".$NON['Nom_Complet']."<br>Adress: ".$NON['Adress']."<br>Email: ".$NON['Email']."<br> Tel: ".$NON['Tel']." <br>Date: ".$NON['Date']."
			<form method='post' action=''>
			<input type='hidden' name='Code' value='".$NON['Code']."'>
			<input type='submit' name='envoye' value='Accepter'>
			</form>";
		}
    if (!isset($CodeFournisseur)) {
      echo "Aucun Fournisseur n'est au fil du mur";
    }
		if (isset($_POST['envoye'])) {
			$Code=$_POST['Code'];
			echo "Code: ".$Code;
			$Confirmer=$conn->query("UPDATE compte SET Activation='OUI' WHERE Code='$Code' and Activation='NON' ");
		}

		$conn=null;
	}




	if ($_SESSION['parametre']=="Accepter") {
		echo "Accepter";

		include('ConnexionDataBase.php');
		echo"<form method='post' action=''>
		<SELECT name='choix'>";
		$liste=$conn->query("SELECT * FROM compte WHERE Activation='OUI' and Tache='Fournisseur'");
		while ($Trouver=$liste->fetch()) {
			echo "<option value='".$Trouver['Code']."'>".$Trouver['Nom_Complet']."</option>";
		}
		echo"</SELECT>
		<input type='submit' name='lesProduits' value='Choix'>
		</form>";
		if (isset($_POST['lesProduits'])) {
			$Choix=$_POST['choix'];

			$Produit=$conn->query("SELECT * FROM produit WHERE CodeFournisseur='$Choix' and Valider='NON' ");
			while ($RechProduit=$Produit->fetch()) {
				$CodeProduit=$RechProduit['CodeProduit'];
				echo "<br>".'<img src="img/Produits/'.$RechProduit['Image'].'"'." width=10% class= animated bounceInDown/><br/> ".$RechProduit['NomProduit']."<br>Commentaire: ".$RechProduit['Description']."<br>Prix Unitaire: ".$RechProduit['PrixUnitaire']." Gdes<br> Quantite: ".$RechProduit['QuantiteProduit']." Pcs <br>Activation Du Produit

				<form method='post' action=''>
				<input type='hidden' name='codeproduit' value='".$CodeProduit."'>
				<input type='number' name='Quantite' size='3' placeholder='Qte...'>
				<input type='submit' name='prduit' value='Valider'>
				</form>";
			}
		}
    if (!isset($CodeProduit)) {
      echo "Tous les Produits de votre fournisseur ont ete aprouve";
    }
		if (isset($_POST['prduit'])) {
				echo "OK";
				$Quantite=htmlspecialchars($_POST['Quantite']);
				$CodeProduit=$_POST['codeproduit'];
				echo "<br>Code Produit:".$CodeProduit;
				if (!empty($Quantite)) {
					$Confirmer=$conn->query("UPDATE produit SET Valider='OUI', QuantiteProduit='$Quantite' WHERE CodeProduit='$CodeProduit' and Valider='NON' ");
				}else{
					echo "Entre la quantite du produit";
				}
			}else{
				$Produit=$conn->query("SELECT * FROM produit WHERE Valider='NON' ");
			while ($RechProduit=$Produit->fetch()) {
				$CodeProduit=$RechProduit['CodeProduit'];
				echo "<br>".'<img src="img/Produits/'.$RechProduit['Image'].'"'." width=10% class= animated bounceInDown/><br/> ".$RechProduit['NomProduit']."<br>Commentaire: ".$RechProduit['Description']."<br>Prix Unitaire: ".$RechProduit['PrixUnitaire']." Gdes<br> Quantite: ".$RechProduit['QuantiteProduit']." Pcs <br>Activation Du Produit

				<form method='post' action=''>
				<input type='hidden' name='codeproduit' value='".$CodeProduit."'>
				<input type='number' name='Quantite' size='3' placeholder='Qte...'>
				<input type='submit' name='prduit' value='Valider'>
				</form>";
			}
			}
		$conn=null;
	}



	if ($_SESSION['parametre']=="tout") {
		include('ConnexionDataBase.php');
		echo"<form method='post' action=''>
		<SELECT name='choix'>";
		$liste=$conn->query("SELECT distinct Tache FROM compte ");
		while ($Trouver=$liste->fetch()) {
			echo "<option value='".$Trouver['Tache']."'>".$Trouver['Tache']."</option>";
		}
		echo"</SELECT>
		<input type='submit' name='lesProduits' value='Choix'>
		</form>";
		if (isset($_POST['lesProduits'])) {
			$Choix=$_POST['choix'];
			$Produit=$conn->query("SELECT * FROM compte WHERE Tache='$Choix' ");
			while ($RechProduit=$Produit->fetch()) {
				$CodeProduit=$RechProduit['Code'];
				echo "<br>".'<img src="img/ImageCompte/'.$RechProduit['Photo'].'"'." width=10% class= animated bounceInDown/><br/>Nom Complet: ".$RechProduit['Nom_Complet']."<br>Adress: ".$RechProduit['Adress']."<br>Telephone: ".$RechProduit['Tel'];
			}
		}else{
			$Produit=$conn->query("SELECT * FROM compte ");
			while ($RechProduit=$Produit->fetch()) {
				$CodeProduit=$RechProduit['Code'];
				echo "<br>".'<img src="img/ImageCompte/'.$RechProduit['Photo'].'"'." width=10% class= animated bounceInDown/><br/>Nom Complet: ".$RechProduit['Nom_Complet']."<br>Adress: ".$RechProduit['Adress']."<br>Telephone: ".$RechProduit['Tel']."<br> Fonction: ".$RechProduit['Tache'];
			}
		}
		$conn=null;
	}

	if ($_SESSION['parametre']=="Info") {
		echo "Info sur le retrait de chaque personne";
    include('ConnexionDataBase.php');
    echo "<form method='post' action=''>";
          $Categorie=$conn->query("SELECT r.CodePersonne,c.Code,c.Nom_Complet FROM compte c, retrait r WHERE r.CodePersonne=c.Code");
          echo "<SELECT name='choix'>";
          while ($Cata=$Categorie->fetch()) {
            echo"<option VALUE='".$Cata['Code']."'>".$Cata['Nom_Complet']."</option><br>";
          }
          echo "</SELECT>";
          echo "<input type='submit' name='bouton' value='Recherche'>";
        echo "</form>";
				?>
		<?php

		if (isset($_POST['bouton'])) {

      if (!empty($_POST['choix'])) {
        $Choix=$_POST['choix'];
        $Trouver=$conn->query("SELECT * FROM retrait WHERE CodePersonne='$Choix' ");
  			while ($V=$Trouver->fetch()) {
  				echo "Date:".$V['Date']." Info".$V['AdressIP']."<br>";
  			}

      }else {
        echo "La liste est vide";
      }

			echo "tout";
		}else{
			$Trouver=$conn->query("SELECT * FROM retrait ");
			while ($V=$Trouver->fetch()) {
				echo "Date:".$V['Date']." Info".$V['AdressIP']."<br>";
			}
		}
	}


  ?>
