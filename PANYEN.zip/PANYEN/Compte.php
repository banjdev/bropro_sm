<?php
session_start();
if ($_SESSION['NomComplet']==null) {
  header('loaction:Deconnection.php');
}
 ?>
 <!DOCTYPE HTML>
 <html>
 <head><title>test intro</title>
 	<meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <script src="js/jquery-3.3.1.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
 	<link rel="stylesheet" href="css/bootstrap.min.css">
 	<link href="css/mdb.min.css" rel="stylesheet">
 	<link rel="stylesheet" type="text/css" href="css/style.css"/>
  <meta property="og:url"           content="192.168.137.1/panyen/" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Your Website Title" />
  <meta property="og:description"   content="Your description" />
  <meta property="og:image"         content="192.168.137.1/panyen/img/logo.png" />
 </head>
 <body>
   <div id="fb-root"></div>
   <script async defer crossorigin="anonymous" src="https://connect.facebook.net/fr_CA/sdk.js#xfbml=1&version=v3.2"></script>
   <div class="container-fluid">
     <div class="row" id="connexion">
        <div class="col-md-4">
          <p><img src="img/logo.png" width="90%"/></p>
        </div>
        <div class="col-md-4">
          <?php
            echo "<a href='?ch=photo'>"."<b><img  src='img/ImageCompte/".$_SESSION['Photo']."'  class='photo' width=20%/></b></a>";
          ?>
        </div>
        <div id="info_C" class="col-md-4">
          <?php
            echo "<b>" .$_SESSION['NomComplet']."</b>";
            echo "<br><b>Compte: ".$_SESSION['Tache']."</b>";
            echo "<br><b>La Balance de votre Compte est: ".$_SESSION['Montant']."</b>";
            echo '<br><a href="Deconnection.php?deconnexion">Deconnection</a>';
            ?>
        </div>
      </div>
    </div>
          <?php
            //===========================Menu============================
            if($_SESSION['Tache']=="Fournisseur" or $_SESSION['Tache']=="Argent" or $_SESSION['Tache']=="Administration" ){
              echo'<nav id="menu">
                <ul>
                  <li><a href="Compte.php?ch=param"><img src="img/parametre.png" class="animated bounceInLeft"></a></li>';
                  echo '<li><a href="Compte.php?ch=solde"><img src="img/solde.png" class="animated bounceInLeft"></a></li>';

                  if($_SESSION["Tache"]=="Fournisseur") {
                    if ($_SESSION['Activation']=="OUI") {
                      echo '<li><a href="Compte.php?ch=pro1"><img src="img/add-prodwi.png" class="animated bounceInLeft"></a></li>';
                    }
                    echo '
                    <li><a href="Compte.php?ch=pro"><img src="img/prodwi.png" class="animated bounceInLeft"></a></li>';
                  }




                 if($_SESSION["Tache"]=="Argent") {
                   echo'<li>
                     <li><a href="Compte.php?ch=pro"><img src="img/pataje.png" class="animated bounceInLeft"></a></li>';
                     //<li><a href="Compte.php?ch=pro"><img src="img/depataje.png" class="animated bounceInLeft"></a></li>
                  }

                  if($_SESSION["Tache"]=="Administration") {
                    echo '

                  <li><a href="?ch=Confirm"><img src="img/pataje.png">Confirmer le Fournisseur</a></li>
                    <li><a href="?ch=tout"><img src="">Tous les Personnes</a></li>
                    <li><a href="?ch=Info"><img src="">Info Retrait</a></li>
                    <li><a href="?ch=Accepter"><img src="">Accepter les Produits</a></li>';
                  }
                  echo '</ul>';
              echo'</nav>';


            }else {
              header("location:Deconnection.php");
            }

           ?>


           <?php
           //===================================Action Sur le Menu====================================
              if ($_GET['ch']=='param') {
                $_SESSION['parametre']="param";
                include('Parametre.php');

              }
              if ($_GET['ch']=='pro') {
echo'<div class="parallaxpro"></div>';

                $_SESSION['parametre']="pro";
                include('Produit.php');
              }
              if ($_GET['ch']=='photo') {
                $_SESSION['parametre']="photo";
                include('Parametre.php');
              }
              if ($_GET['ch']=='solde') {
                $_SESSION['parametre']="solde";
                include('Parametre.php');
              }
              if ($_GET['ch']=='pro1') {
                $_SESSION['parametre']="pro1";
                include('Produit.php');
              }
              if ($_GET['ch']=='Confirm') {
                $_SESSION['parametre']="Confirm";
                include('CompteAdmin.php');
              }
              if ($_GET['ch']=='Accepter') {
                $_SESSION['parametre']="Accepter";
                include('CompteAdmin.php');
              }
              if ($_GET['ch']=='tout') {
                $_SESSION['parametre']="tout";
                include('CompteAdmin.php');
              }
              if ($_GET['ch']=='Info') {
                $_SESSION['parametre']="Info";
                include('CompteAdmin.php');
              }


          ?>
          <footer>
          	<div class="container-fluid">
          		<div class="row">
          			<div class="col-md-12">
          			<p><img src="img/logo2.png" width="40%"></p>
          			<P>PANYEN AN NOU 2019</P>
          		</div>

          		</div>
          	</div>
          </footer>
 </body>
